importScripts('luayi.js');
const MAX_OUT = 64 * 1024;
onmessage = async e => {
  let text = '', cut = false;
  const add = l => { if (text.length < MAX_OUT) text += l + '\n'; else cut = true; };
  try {
    const M = await createLuayi({ print: add, printErr: add });
    const exitCode = M.ccall('luayi_run', 'number', ['string'], [e.data.code]);
    postMessage({ type: 'done', exitCode, text: text.slice(0, MAX_OUT) + (cut ? '[output dipotong]' : '') });
  } catch (err) {
    postMessage({ type: 'done', exitCode: 1, text: text + '\nRuntime crash: ' + (err && err.message || err) });
  }
};
