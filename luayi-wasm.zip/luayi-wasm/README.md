# Luayi WASM
Luayi jalan 100% di browser (WebAssembly). Nggak ada server/backend, jadi tinggal upload folder `site/` ke hosting statis apa aja (Wasmer Edge static, Vercel, Cloudflare Pages, GitHub Pages).

## Build (sekali aja)
Butuh emscripten. Paling gampang lewat Docker (jalan di ARM/x86, Linux/Mac/Windows):

    docker run --rm -v "$PWD":/work -w /work emscripten/emsdk bash build.sh

Hasil: `site/luayi.js` dan `site/luayi.wasm`. Tes lokal: `cd site && python3 -m http.server 8000`.

## Isi
- `src/` : source Luau (VM, Compiler, Ast, Bytecode, Common) + `CustomFuncs.cpp` (versi yang udah difix) + `luayi_web.cpp` (entry point)
- `site/` : index.html + worker.js (+ luayi.js/wasm setelah build)
