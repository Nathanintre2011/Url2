// Entry point WASM: jalanin 1 script Luau dari string, output lewat stdout/stderr.
#include "lua.h"
#include "lualib.h"
#include "luacode.h"
#include <cstdio>
#include <cstdlib>

extern "C" void register_custom_funcs(lua_State* L);

extern "C" int luayi_run(const char* source) {
    lua_State* L = luaL_newstate();
    if (!L) { fprintf(stderr, "Gagal bikin lua_State\n"); return 1; }
    luaL_openlibs(L);
    register_custom_funcs(L);

    size_t n = 0;
    while (source[n]) n++;
    size_t bcSize = 0;
    char* bc = luau_compile(source, n, NULL, &bcSize);
    if (!bc) { fprintf(stderr, "Gagal compile script\n"); lua_close(L); return 1; }

    if (luau_load(L, "script.luau", bc, bcSize, 0) != 0) {
        fprintf(stderr, "Gagal load: %s\n", lua_tostring(L, -1));
        free(bc); lua_close(L); return 1;
    }
    free(bc);

    int st = lua_resume(L, NULL, 0);
    if (st != LUA_OK && st != LUA_YIELD) fprintf(stderr, "Error: %s\n", lua_tostring(L, -1));
    fflush(stdout); fflush(stderr);
    lua_close(L);
    return st == LUA_OK ? 0 : 1;
}
