// CustomFuncs.cpp
// FULL implementation - hook beneran, bukan dummy
// Wajib compile bareng source Luau (akses internal headers)

#include "lua.h"
#include "lualib.h"
#include "luacode.h" // luau_compile, buat load/loadstring custom di bawah

// Internal Luau headers - INI YANG BIKIN BISA HOOK BENERAN
#include "lobject.h"
#include "lstate.h"
#include "ldo.h"
#include "lfunc.h"
#include "lgc.h"
#include "lstring.h"
#include "lapi.h" // luaA_toobject

// lstate.h #define-s a macro named `isLua(ci)` for CallInfo*, which
// textually collides with a `->isLua()` member call on Closure. This build
// of Luau doesn't have such a method anyway (Closure is a plain C struct
// with a public `isC` field: true = C closure, false = Lua closure), so
// every check below uses `!cl->isC` directly instead of a same-named call.

#include <cstring>
#include <cstdio>
#include <cstdlib>

// ============================================================
// HELPER: Ambil function object dari stack index
// ============================================================

static Closure* getclosure(lua_State* L, int idx) {
    const TValue* o = luaA_toobject(L, idx);
    if (o && ttisfunction(o)) {
        return clvalue(o);
    }
    return nullptr;
}

// ============================================================
// 0. LOAD / LOADSTRING
// luaL_openlibs() di Luau nggak expose ini (host yang milih nge-expose
// atau nggak, beda dari asumsi obfuscator yang anggap load/loadstring
// salah satunya pasti ada). Di sini kita beneran compile+load, bukan stub,
// biar obfuscator lo bisa dites end-to-end (bukan selalu mentok di
// "[si] load_unavailable" / "[de] load missing").
// ============================================================

static int lua_load_custom(lua_State* L) {
    size_t srcLen = 0;
    const char* src = luaL_checklstring(L, 1, &srcLen);
    const char* chunkname = luaL_optstring(L, 2, src);

    size_t bytecodeSize = 0;
    char* bytecode = luau_compile(src, srcLen, NULL, &bytecodeSize);
    if (!bytecode) {
        lua_pushnil(L);
        lua_pushstring(L, "luau_compile failed");
        return 2;
    }

    int result = luau_load(L, chunkname, bytecode, bytecodeSize, 0);
    free(bytecode);

    if (result != 0) {
        // luau_load sudah push error message di stack; susun ulang jadi
        // (nil, errmsg) sesuai konvensi load() standar.
        lua_pushnil(L);
        lua_insert(L, -2);
        return 2;
    }
    return 1; // function hasil compile ada di stack
}

// ============================================================
// Trampoline buat kasus C -> Luau.
// Closure C dan Closure Lua punya layout union yang beda ukuran
// (sizeCclosure/sizeLclosure di lfunc.h beda offset), jadi nggak aman
// langsung nimpa proto/nupvalues punya target C dengan punya replacement
// Lua - bisa overflow memory kalau nupvalues replacement lebih besar dari
// yang teralokasi buat target. Solusinya: target TETAP jadi C closure
// (ukuran alokasi nggak berubah), cuma c.f-nya diarahkan ke trampoline
// bersama ini. Trampoline cari tau "dirinya sedang jadi target yang mana"
// lewat curr_func(L) (identitas closure yang lagi jalan - ini stabil
// karena target objectnya sendiri yang dipanggil, cuma c.f-nya yang beda),
// lalu panggil replacement Lua yang disimpan di registry.
// ============================================================

static int hook_trampoline(lua_State* L) {
    Closure* target = curr_func(L);
    char replKey[64];
    snprintf(replKey, sizeof(replKey), "__hook_repl_%p", (void*)target);
    lua_getfield(L, LUA_REGISTRYINDEX, replKey);
    if (!lua_isfunction(L, -1)) {
        luaL_error(L, "hookfunction: trampoline kehilangan replacement (sudah di-restore?)");
    }
    int nargs = lua_gettop(L) - 1;
    lua_insert(L, 1); // replacement pindah ke bawah, argumen asli ikut
    lua_call(L, nargs, LUA_MULTRET);
    return lua_gettop(L);
}

// ============================================================
// 1. HOOKFUNCTION - Implementasi beneran
// Ganti proto dari function target dengan proto dari hook
// Return original function
// ============================================================

static int lua_hookfunction(lua_State* L) {
    // Argumen: target (1), replacement (2)
    luaL_checktype(L, 1, LUA_TFUNCTION);
    luaL_checktype(L, 2, LUA_TFUNCTION);
    
    Closure* target = getclosure(L, 1);
    Closure* replacement = getclosure(L, 2);
    
    if (!target || !replacement) {
        luaL_error(L, "hookfunction: invalid function");
    }
    
    // Cek tipe closure
    bool target_isL = !target->isC;
    bool repl_isL = !replacement->isC;
    
    if (target_isL && repl_isL) {
        // Luau -> Luau: swap proto
        Proto* original_proto = target->l.p;
        target->l.p = replacement->l.p;
        
        // Push original function (yang sekarang punya proto baru)
        lua_pushvalue(L, 1);
        
        // Simpan referensi original proto di registry biar bisa restore
        // Format: registry["__hook_orig_" + tostring(target_ptr)] = proto
        char key[64];
        snprintf(key, sizeof(key), "__hook_orig_%p", (void*)target);
        lua_pushlightuserdata(L, (void*)original_proto);
        lua_setfield(L, LUA_REGISTRYINDEX, key);
        
        return 1;
    }
    else if (!target_isL && repl_isL) {
        // C -> Luau: target tetap C closure (alokasi & identitas nggak
        // berubah), cuma c.f diarahkan ke hook_trampoline bersama di atas.
        // Replacement Lua-nya disimpan di registry, dikunci dari pointer
        // target sendiri, biar trampoline bisa nemuin lagi pas dipanggil.
        //
        // PENTING: beberapa C closure builtin (pcall, xpcall, dst) didaftar
        // lewat lua_pushcclosurek() dengan c.cont terisi (continuation,
        // dipanggil VM buat nyelesain protected call, termasuk di jalur
        // non-yield). Kalau cont lama ini dibiarin nempel sementara c.f
        // udah ganti, VM bisa manggil continuation asli itu lagi setelah
        // trampoline selesai - continuation itu nggak nyambung sama hasil
        // trampoline, hasilnya pemanggilan ganda/nilai nyasar. Makanya
        // cont ikut disimpen & dinolin di sini, dan dibalikin di restore.
        void* original_f = (void*)target->c.f;
        void* original_cont = (void*)target->c.cont;
        target->c.f = hook_trampoline;
        target->c.cont = nullptr;

        char replKey[64];
        snprintf(replKey, sizeof(replKey), "__hook_repl_%p", (void*)target);
        lua_pushvalue(L, 2);
        lua_setfield(L, LUA_REGISTRYINDEX, replKey);

        lua_pushvalue(L, 1);

        char key[64];
        snprintf(key, sizeof(key), "__hook_orig_%p", (void*)target);
        lua_pushlightuserdata(L, original_f);
        lua_setfield(L, LUA_REGISTRYINDEX, key);

        char contKey[64];
        snprintf(contKey, sizeof(contKey), "__hook_cont_%p", (void*)target);
        lua_pushlightuserdata(L, original_cont);
        lua_setfield(L, LUA_REGISTRYINDEX, contKey);

        return 1;
    }
    else if (target_isL && !repl_isL) {
        // Luau -> C: ganti proto dengan C closure wrapper
        luaL_error(L, "hookfunction: Luau->C hook belum diimplementasi penuh");
    }
    else {
        // C -> C: swap c.f pointer (lihat catatan soal c.cont di atas -
        // berlaku sama di sini)
        void* original_f = (void*)target->c.f;
        void* original_cont = (void*)target->c.cont;
        target->c.f = replacement->c.f;
        target->c.cont = nullptr;

        lua_pushvalue(L, 1);
        
        char key[64];
        snprintf(key, sizeof(key), "__hook_orig_%p", (void*)target);
        lua_pushlightuserdata(L, original_f);
        lua_setfield(L, LUA_REGISTRYINDEX, key);

        char contKey[64];
        snprintf(contKey, sizeof(contKey), "__hook_cont_%p", (void*)target);
        lua_pushlightuserdata(L, original_cont);
        lua_setfield(L, LUA_REGISTRYINDEX, contKey);

        return 1;
    }
}

// ============================================================
// 2. RESTOREFUNCTION - Balikin function ke asli
// ============================================================

static int lua_restorefunction(lua_State* L) {
    // Argumen: hooked (1) [optional: original (2)]
    luaL_checktype(L, 1, LUA_TFUNCTION);
    
    Closure* hooked = getclosure(L, 1);
    if (!hooked) {
        luaL_error(L, "restorefunction: invalid function");
    }
    
    char key[64];
    snprintf(key, sizeof(key), "__hook_orig_%p", (void*)hooked);
    
    // Ambil original dari registry
    lua_getfield(L, LUA_REGISTRYINDEX, key);
    if (lua_isnil(L, -1)) {
        lua_pop(L, 1);
        lua_pushboolean(L, 0); // Nggak ada yang di-restore
        return 1;
    }
    
    if (!hooked->isC) {
        Proto* original_proto = (Proto*)lua_touserdata(L, -1);
        hooked->l.p = original_proto;
    } else {
        void* original_f = lua_touserdata(L, -1);
        hooked->c.f = (lua_CFunction)original_f;

        // Balikin juga c.cont kalau ada yang disimpen (lihat catatan di
        // lua_hookfunction soal pcall/xpcall dkk).
        char contKey[64];
        snprintf(contKey, sizeof(contKey), "__hook_cont_%p", (void*)hooked);
        lua_getfield(L, LUA_REGISTRYINDEX, contKey);
        hooked->c.cont = (lua_Continuation)lua_tolightuserdata(L, -1);
        lua_pop(L, 1);
        lua_pushnil(L);
        lua_setfield(L, LUA_REGISTRYINDEX, contKey);
    }
    
    lua_pop(L, 1);
    
    // Hapus dari registry
    lua_pushnil(L);
    lua_setfield(L, LUA_REGISTRYINDEX, key);
    
    lua_pushboolean(L, 1);
    return 1;
}

// ============================================================
// 3. GETFENV / SETFENV - pakai lua_getfenv/lua_setfenv bawaan Luau
// ============================================================

// Push function di level stack tertentu (1 = caller). false kalau level invalid.
static bool push_func_at_level(lua_State* L, int level) {
    lua_Debug ar;
    return level > 0 && lua_getinfo(L, level, "f", &ar);
}

static int lua_getfenv_custom(lua_State* L) {
    // getfenv([f|level]) -> table; default level 1 (caller)
    if (lua_isnoneornil(L, 1)) {
        if (!push_func_at_level(L, 1)) {
            lua_pushvalue(L, LUA_GLOBALSINDEX);
            return 1;
        }
        lua_getfenv(L, -1); // env di atas function
        return 1;
    }

    if (lua_isfunction(L, 1)) {
        lua_getfenv(L, 1);
        return 1;
    }

    if (lua_isnumber(L, 1)) {
        int level = (int)lua_tointeger(L, 1);
        if (level == 0) { // level 0 = global env thread
            lua_pushvalue(L, LUA_GLOBALSINDEX);
            return 1;
        }
        if (!push_func_at_level(L, level)) {
            luaL_argerror(L, 1, "invalid level");
        }
        lua_getfenv(L, -1);
        return 1;
    }

    luaL_typeerror(L, 1, "function or number");
    return 0;
}

static int lua_setfenv_custom(lua_State* L) {
    // setfenv(f|level, table) -> function
    luaL_checktype(L, 2, LUA_TTABLE);

    if (lua_isfunction(L, 1)) {
        lua_pushvalue(L, 2);
        if (!lua_setfenv(L, 1)) {
            luaL_error(L, "setfenv: nggak bisa set env function ini");
        }
        lua_pushvalue(L, 1);
        return 1;
    }

    if (lua_isnumber(L, 1)) {
        int level = (int)lua_tointeger(L, 1);
        if (!push_func_at_level(L, level)) {
            luaL_argerror(L, 1, "invalid level");
        }
        lua_pushvalue(L, 2);
        if (!lua_setfenv(L, -2)) {
            luaL_error(L, "setfenv: nggak bisa set env function ini");
        }
        return 1; // function di level itu
    }

    luaL_typeerror(L, 1, "function or number");
    return 0;
}

// ============================================================
// 3b. GETRENV - environment "asli" host, sebelum custom funcs masuk
// Snapshot global dibikin sekali pas register_custom_funcs(), jadi
// hasil setfenv/hookfunction/global baru dari script nggak bocor ke sini.
// ============================================================

static int lua_getrenv(lua_State* L) {
    lua_getfield(L, LUA_REGISTRYINDEX, "__renv");
    if (!lua_istable(L, -1)) {
        lua_pop(L, 1);
        lua_pushvalue(L, LUA_GLOBALSINDEX); // fallback
    }
    return 1;
}

static void snapshot_renv(lua_State* L) {
    lua_newtable(L); // snapshot
    lua_pushnil(L);
    while (lua_next(L, LUA_GLOBALSINDEX)) { // iterasi global
        lua_pushvalue(L, -2); // key
        lua_pushvalue(L, -2); // value
        lua_rawset(L, -5);    // snapshot[key] = value
        lua_pop(L, 1);        // buang value, sisain key buat next
    }
    lua_setfield(L, LUA_REGISTRYINDEX, "__renv");
}

// ============================================================
// 4. ISLCLOSURE / ISCCLOSURE - deteksi apakah function sudah
// diganti jadi Lua closure (dipakai obfuscator buat anti-hook)
// ============================================================

static int lua_islclosure(lua_State* L) {
    luaL_checktype(L, 1, LUA_TFUNCTION);
    Closure* cl = getclosure(L, 1);
    lua_pushboolean(L, cl && !cl->isC);
    return 1;
}

static int lua_iscclosure(lua_State* L) {
    luaL_checktype(L, 1, LUA_TFUNCTION);
    Closure* cl = getclosure(L, 1);
    lua_pushboolean(L, cl && cl->isC);
    return 1;
}

// ============================================================
// 5. DEBUG.INFO - Implementasi beneran
// ============================================================

static int lua_debug_info(lua_State* L) {
    // debug.info([thread], [function|level], options)
    int arg_start = 1;
    if (lua_isthread(L, 1)) arg_start = 2;

    const char* options = luaL_checkstring(L, arg_start + 1);

    // lua_getinfo doesn't take the function as a stack arg + ">" prefix like
    // PUC-Lua; this Luau's convention (see VM/src/ldblib.cpp db_info) is: push
    // the function on top of the stack, then pass a NEGATIVE level equal to
    // -lua_gettop(L) so it points back at that stack slot.
    int level;
    if (lua_isnumber(L, arg_start)) {
        level = (int)lua_tointeger(L, arg_start);
    } else if (lua_isfunction(L, arg_start)) {
        lua_pushvalue(L, arg_start);
        level = -lua_gettop(L);
    } else {
        return 0;
    }

    lua_Debug ar;
    if (!lua_getinfo(L, level, options, &ar)) return 0;
    
    int nresults = 0;
    for (const char* p = options; *p; p++) {
        switch (*p) {
            case 's': lua_pushstring(L, ar.source ? ar.source : "?"); nresults++; break;
            case 'l': lua_pushinteger(L, ar.currentline); nresults++; break;
            case 'n': lua_pushstring(L, ar.name ? ar.name : ""); nresults++; break;
            case 'a':
                lua_pushinteger(L, ar.nparams);
                lua_pushboolean(L, ar.isvararg);
                nresults += 2;
                break;
        }
    }
    return nresults;
}

// ============================================================
// 6. GETRAWMETATABLE - Bypass __metatable lock
// ============================================================

static int lua_getrawmetatable(lua_State* L) {
    luaL_checkany(L, 1);
    // lua_getmetatable() in this Luau build already doesn't check the
    // __metatable lock field (see VM/src/lapi.cpp) - it just pushes the
    // real metatable for tables/userdata/vectors/etc. via L->global->mt[].
    // So "raw" here is just that public function; no need to reach into
    // internal headers (the previous version of this function reached for
    // Table/G(), neither of which exist in this Luau build, and always
    // returned nil regardless of what it found).
    if (lua_getmetatable(L, 1)) {
        return 1;
    }
    lua_pushnil(L);
    return 1;
}

// ============================================================
// 7. SETREADONLY / ISREADONLY - Table readonly control
// ============================================================

static int lua_setreadonly(lua_State* L) {
    luaL_checktype(L, 1, LUA_TTABLE);
    luaL_checktype(L, 2, LUA_TBOOLEAN);
    
    LuaTable* t = hvalue(luaA_toobject(L, 1));
    if (t) {
        if (lua_toboolean(L, 2)) {
            t->readonly = 1;
        } else {
            t->readonly = 0;
        }
    }
    
    lua_pushvalue(L, 1);
    return 1;
}

static int lua_isreadonly(lua_State* L) {
    luaL_checktype(L, 1, LUA_TTABLE);
    
    LuaTable* t = hvalue(luaA_toobject(L, 1));
    if (t) {
        lua_pushboolean(L, t->readonly);
    } else {
        lua_pushboolean(L, 0);
    }
    return 1;
}

// ============================================================
// REGISTRASI
// ============================================================

static const luaL_Reg custom_globals[] = {
    {"load", lua_load_custom},
    {"loadstring", lua_load_custom},
    {"getfenv", lua_getfenv_custom},
    {"setfenv", lua_setfenv_custom},
    {"getrenv", lua_getrenv},
    {"hookfunction", lua_hookfunction},
    {"restorefunction", lua_restorefunction},
    {"getrawmetatable", lua_getrawmetatable},
    {"setreadonly", lua_setreadonly},
    {"isreadonly", lua_isreadonly},
    {"islclosure", lua_islclosure},
    {"iscclosure", lua_iscclosure},
    {NULL, NULL}
};

static const luaL_Reg custom_debug_funcs[] = {
    {"info", lua_debug_info},
    {NULL, NULL}
};

extern "C" void register_custom_funcs(lua_State* L) {
    snapshot_renv(L); // harus duluan, sebelum global custom masuk

    lua_pushvalue(L, LUA_GLOBALSINDEX);
    luaL_register(L, NULL, custom_globals);
    lua_pop(L, 1);
    
    lua_getglobal(L, "debug");
    if (lua_istable(L, -1)) {
        luaL_register(L, NULL, custom_debug_funcs);
    }
    lua_pop(L, 1);
}
