#!/usr/bin/env bash
# Compile Luau + CustomFuncs ke WASM (butuh emscripten: emcc).
# Tanpa emsdk lokal:  docker run --rm -v "$PWD":/work -w /work emscripten/emsdk bash build.sh
set -e
cd "$(dirname "$0")"
SRC=$(ls src/VM/src/*.cpp src/Compiler/src/*.cpp src/Ast/src/*.cpp src/Bytecode/src/*.cpp src/Common/src/*.cpp)
emcc -O2 -std=c++17 -fexceptions -DNDEBUG \
  -Isrc/VM/include -Isrc/VM/src -Isrc/Compiler/include -Isrc/Ast/include -Isrc/Common/include -Isrc/Bytecode/include \
  $SRC src/CustomFuncs.cpp src/luayi_web.cpp \
  -o site/luayi.js \
  -fexceptions \
  -sMODULARIZE=1 -sEXPORT_NAME=createLuayi -sENVIRONMENT=worker \
  -sEXPORTED_FUNCTIONS=_luayi_run -sEXPORTED_RUNTIME_METHODS=ccall \
  -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=33554432 -sMAXIMUM_MEMORY=536870912
ls -la site/luayi.js site/luayi.wasm
